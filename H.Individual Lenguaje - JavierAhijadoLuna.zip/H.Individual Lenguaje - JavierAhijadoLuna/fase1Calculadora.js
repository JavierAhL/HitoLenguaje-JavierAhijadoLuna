// Seleccionamos los elementos del DOM
const calculator = document.querySelector('.calculator');
const keys = calculator.querySelector('.calculator__keys');
const display = calculator.querySelector('.calculator__display');

// Creamos una variable que mantendrá el estado actual de la calculadora
let firstValue = null;
let operator = null;
let waitingForSecondValue = false;

// Función para resetear la calculadora
function resetCalculator() {
  firstValue = null;
  operator = null;
  waitingForSecondValue = false;
  display.textContent = '0';
}

// Función para actualizar la pantalla de la calculadora
function updateDisplay(value) {
  display.textContent = value;
}

// Función para realizar cálculos matemáticos fisrt value y despues darle al second value antes de dar a ejecutar y que salga el resultado total
function performCalculation() {
  const secondValue = parseFloat(display.textContent);
  let result = 0;
  switch (operator) {
    case 'add':
      result = firstValue + secondValue;
      break;
    case 'subtract':
      result = firstValue - secondValue;
      break;
    case 'multiply':
      result = firstValue * secondValue;
      break;
    case 'divide':
      result = firstValue / secondValue;
      break;
    case 'porcentaje':
      result = (firstValue * secondValue) / 100;
      break;
    case 'cuadrado':
      result = Math.pow(firstValue, 2);
      break;
    case 'raiz':
      result = Math.sqrt(firstValue);
      break;
    default:
      break;
  }
  updateDisplay(result);
  firstValue = result;
  waitingForSecondValue = true;
}

// Función para manejar los clics en los botones
keys.addEventListener('click', (e) => {
  if (e.target.matches('button')) {
    const key = e.target;
    const action = key.dataset.action;
    const keyValue = key.textContent;

    // Manejamos los clics en los botones de número
    if (!action) {
      if (waitingForSecondValue) {
        updateDisplay(keyValue);
        waitingForSecondValue = false;
      } else {
        const currentValue = display.textContent;
        updateDisplay(currentValue === '0' ? keyValue : currentValue + keyValue);
      }
    }

    // Manejamos los clics en los botones de punto decimal
    if (action === 'decimal') {
      if (waitingForSecondValue) {
        updateDisplay('0.');
        waitingForSecondValue = false;
      } else if (!display.textContent.includes('.')) {
        updateDisplay(display.textContent + '.');
      }
    }

    // Manejamos los clics en los botones de operadores
    if (
      action === 'add' ||
      action === 'subtract' ||
      action === 'multiply' ||
      action === 'divide' ||
      action === 'porcentaje' ||
      action === 'cuadrado' ||
      action === 'raiz'
    ) {
      if (!firstValue) {
        firstValue = parseFloat(display.textContent);
        operator = action;
        waitingForSecondValue = true;
      } else {
        performCalculation();
        operator = action;
      }
    }

    // Manejamos los clics en el botón de borrar (AC)
    if (action === 'clear') {
      resetCalculator();
    }

    // Manejamos los clics en el botón de igual (=)
    if (action === 'calculate') {
        performCalculation();
        operator = null;
      }
    }
  });
